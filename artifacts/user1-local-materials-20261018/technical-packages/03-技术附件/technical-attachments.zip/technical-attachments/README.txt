技术附件说明
这些附件与代码提交包分开保存，可按需要取用；不是正式报告、互评表或视频。
ERD/: 三种格式的数据库关系图。documentation-and-checks/: 源码文档和已保留的检查结果。
evidence-20261016/ 与 evidence-public-history/: 原日期的本地测试截图、JSON 和日志，按原样复制。
packaging-20261017/: 本次公众端/后台生产构建日志及与已验收产物逐字节比对结果。
历史 JSON 中的 PR #17 或“cPanel pending”文字是当时/模板说明，不代表当前部署未完成。
这些历史结果不等于今天重新执行了全部测试，也不是老师的验收结论。
两份你自行修改的本地验收/交接文档没有收录，原文件没有修改。
源码生成器在 API 代码包 source/scripts/generate-code-reference.cjs 中。
