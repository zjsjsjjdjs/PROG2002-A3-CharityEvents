Harbour Hope A3 — technical delivery only

Source commit: df0d5e6f21f7c171a2681fe86d182240ae4cfcfb
Repository: https://github.com/zjsjsjjdjs/PROG2002-A3-CharityEvents
PR #22 contains the documentation/comment additions and was still open at packaging.
The technical packages use its exact source revision; no GitHub merge or deployment was performed.

Course source packages:
- houyan10A3-clientside.zip: source/angular public + shared + workspace configuration; public runtime.
- houyan10A3-adminside.zip: source/angular admin + shared + workspace configuration; admin runtime.
- houyan10A3-api.zip: source/api, clientside validation/legacy source, database, scripts; API runtime and SQL.
Combine both source/angular trees into one workspace. They intentionally share identical configuration/shared files.
Combine all three source/ trees for the complete code and test workspace. Install locked dependencies with
npm ci --prefix angular and npm ci --prefix api. Build with Node 24.19.0 (used here),
then npm run build --prefix angular. Real .env, node_modules and Git history are excluded.
The source environment template defaults to local legacy mode; use runtime/api/.env.example
and APP_FRONTEND=angular when configuring the integrated Angular runtime.

The companion complete-cpanel-release.zip contains one release/ directory.
For a NEW installation, keep it outside public_html, configure api/app.js as startup,
public /, admin /admin/, API /api/. Set APP_FRONTEND=angular,
ANGULAR_PUBLIC_DIR=../frontend/public, ANGULAR_ADMIN_DIR=../frontend/admin,
PUBLIC_ORIGIN to your HTTPS origin, and private admin/DB credentials in the hosting environment.
Run npm ci --omit=dev inside api. Import database/a3-fresh-install.sql ONLY into a NEW EMPTY database.
Do not import sample SQL over an existing live database. Do not upload the entire source tree into public_html.
The existing school deployment is already working: this package is a backup/reproducible delivery,
not an instruction to redeploy, change its a3-api application root, or replace its database.

The school runtime was Node 18.20.8 serving prebuilt assets/API. Angular builds ran locally on 24.19.0.
Use the existing cPanel account configuration for its absolute frontend paths. Do not overwrite Passenger rules.

Separate materials intentionally excluded:
- The student's two editable local acceptance/handoff documents, including committed older copies.
- Final report, personal video, peer evaluation and personal submission/declaration material.
The student packages those separately. The technical attachments contain historical test evidence,
ERD images and generated source reference, not a replacement report or a new live acceptance claim.
